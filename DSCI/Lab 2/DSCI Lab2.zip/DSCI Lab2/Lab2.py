# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd
c1=pd.read_csv("data1.csv")
print(c1)